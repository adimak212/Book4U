package com.example.book4u;


import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import java.util.ArrayList;
import java.util.List;

public class CurrencyAdapter extends RecyclerView.Adapter<CurrencyAdapter.ViewHolder> {
    private List<Coin> coins;

    public CurrencyAdapter(List<Coin> coins) {
        this.coins = coins;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.currency_recycler,parent,false);
        return new ViewHolder(view);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.longName.setText(coins.get(position).getName());
        holder.code.setText(coins.get(position).getShort_code() + " " + coins.get(position).getSymbol());
        holder.setIsRecyclable(false);
    }

    @Override
    public int getItemCount() {
        return coins.size();
    }
    public List<Coin> getList(){
        return coins;
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView longName;
        TextView code;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            longName = itemView.findViewById(R.id.LongName);
            code = itemView.findViewById(R.id.Currency_Code);
        }
    }
}

