package com.example.book4u;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.search.SearchBar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;

import org.checkerframework.checker.units.qual.C;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class currencyActivity extends AppCompatActivity {

    CurrencyAdapter adapter;
    ArrayList<Coin> coins = new ArrayList<>();
    RecyclerView recyclerView;
    LinearLayoutManager layoutManager;
    SearchView searchBar;
    SharedPreferences RememebrMe;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference myref;

    boolean flag = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_currency);
        recyclerView = findViewById(R.id.CurrencyRecycle);
        adapter = new CurrencyAdapter(coins);
        layoutManager = new LinearLayoutManager(getApplicationContext());
        firebaseDatabase = firebaseDatabase.getInstance();
        RememebrMe = this.getSharedPreferences("UserLogedIn", 0);
        myref = firebaseDatabase.getReference("Users").child(RememebrMe.getString("Email", "").replace(".", "|"));
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);
        searchBar = findViewById(R.id.searchView);
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.currencybeacon.com" + "/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        retrofit.create(CurrencyApi.class).getAllCoins("4SBqCstTeBg1jdgdla02OVO58bcLUMqh").enqueue(new Callback<AllCurrencies>() {
            @Override
            public void onResponse(Call<AllCurrencies> call, Response<AllCurrencies> response) {
                coins.addAll(response.body().getResponse());
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onFailure(Call<AllCurrencies> call, Throwable t) {

            }
        });
        recyclerView.addOnItemTouchListener(new RecyclerItemClickListener(getApplicationContext(), recyclerView, new RecyclerItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                    myref.child("code").setValue(adapter.getList().get(position).getShort_code());
                    finish();
            }

            @Override
            public void onLongItemClick(View view, int position) {

            }
        }));
       searchBar.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
           @Override
           public boolean onQueryTextSubmit(String query) {
               adapter = new CurrencyAdapter(SearchForCurrency(query));
               recyclerView.setAdapter(adapter);
               return false;
           }

           @Override
           public boolean onQueryTextChange(String newText) {
               adapter = new CurrencyAdapter(SearchForCurrency(newText));
               recyclerView.setAdapter(adapter);
               return false;
           }
       });
    }
    private ArrayList<Coin> SearchForCurrency(String query){
        ArrayList<Coin> coinsQuery = new ArrayList<>();
        flag = true ;
        for(int i=0; i<coins.size(); i++){
            if(coins.get(i).getShort_code().toUpperCase().contains(query.toUpperCase()) || coins.get(i).getName().toUpperCase().contains(query.toUpperCase())){
                coinsQuery.add(coins.get(i));
            }
        }
        return coinsQuery;
    }
}