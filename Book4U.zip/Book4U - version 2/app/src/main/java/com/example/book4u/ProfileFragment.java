package com.example.book4u;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;

import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;


import com.google.android.gms.tasks.OnSuccessListener;

import com.google.firebase.auth.FirebaseAuth;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ProfileFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ProfileFragment extends Fragment {
    Bundle data ;
    TextView ProfileName;
    ListView listView;
    ArrayAdapter listAdapter;

    StorageReference mStorageRef;
    FirebaseAuth firebaseAuth;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference myref;
SharedPreferences.Editor editor;
    StorageReference storageReference;
    FirebaseStorage firebaseStorage;
    ImageView imageView ;

    SharedPreferences RememebrMe ;
    String DataEmail = "";

    String[] buttons;

    Intent ToSetting;



    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public ProfileFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment ProfileFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static ProfileFragment newInstance(String param1, String param2) {
        ProfileFragment fragment = new ProfileFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);

        }

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

         return inflater.inflate(R.layout.fragment_profile, container, false);


    }

    public void onViewCreated( View view,  Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        RememebrMe = getContext().getSharedPreferences("UserLogedIn" , 0);
        editor = RememebrMe.edit();
       /* editor.putString("PicName" , "1715981599695.jpg");
        editor.commit();*/
        firebaseDatabase = firebaseDatabase.getInstance();
        data = getArguments();
        ToSetting = new Intent(getContext() , SettingActivity.class);
        ProfileName = view.findViewById(R.id.AccountNameProfilePage);
        imageView = view.findViewById(R.id.ProfileImageProfilePage);
        listView =  view.findViewById(R.id.ListViewProfilePage);
        firebaseAuth = FirebaseAuth.getInstance();
        myref = firebaseDatabase.getInstance().getReference("Users");
        storageReference = FirebaseStorage.getInstance().getReference("Images/users/"+RememebrMe.getString("Email" , "").replace("." , "|")).child(RememebrMe.getString("PicName" , ""));

        buttons = new String[]{"favorites", "sell something?", "settings"};
        ArrayList<String> input = new ArrayList<>();
        input.addAll(Arrays.asList(buttons));
        listAdapter = new ArrayAdapter<>(view.getContext(), R.layout.list_view_profile_page, input);
        listView.setAdapter(listAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (buttons[position].equals("settings")){
                    startActivity(ToSetting);
                }// if settings
            }
        });

        getCurrentUser();
        getCurrentUserPhoto(storageReference);

    }
    private void getCurrentUser (){
        firebaseDatabase = firebaseDatabase.getInstance();
        myref = firebaseDatabase.getReference("Users").child(RememebrMe.getString("Email" , "").replace("." , "|"));
        myref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                        ProfileName.setText(snapshot.child("accountName").getValue().toString());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }// getCurrentUser

    private void getCurrentUserPhoto (StorageReference storageReference){
        storageReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                Picasso.get().load(uri).into(imageView);
            }
        });
    }
}