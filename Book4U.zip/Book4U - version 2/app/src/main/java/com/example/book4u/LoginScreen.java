package com.example.book4u;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class LoginScreen extends AppCompatActivity {
    EditText  EmailEditText , PasswordEditText ;
    String  EmailString = "" , PasswordString = "";
    FirebaseAuth firebaseAuth;
    FirebaseDatabase firebaseDatabase=FirebaseDatabase.getInstance();
    DatabaseReference myref;
    Button Login , Register ;
    Intent ToRegister ;
    SharedPreferences RememebrMe ;
    SharedPreferences.Editor RemembrMeEditor ;
    CheckBox flag  ;
    Intent ToMain ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_screen);
        EmailEditText = (EditText) findViewById(R.id.EmailLogin);
        PasswordEditText = (EditText) findViewById(R.id.PassWordLogin);
        Login = findViewById(R.id.LogInButton);
        Register = findViewById(R.id.ToRegisterButton);
        flag = findViewById(R.id.RememberMe);
        ToMain = new Intent(this, ButtonNevigetionMainPage.class);

        firebaseAuth = FirebaseAuth.getInstance();
        myref = firebaseDatabase.getReference("Users");
        ToRegister = new Intent(this , RegisterPage.class);
        RememebrMe = getSharedPreferences("UserLogedIn" , 0);

        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(ToRegister);
                finish();
            }// Register
        });

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EmailString = EmailEditText.getText().toString();
                PasswordString = PasswordEditText.getText().toString();

                firebaseAuth.signInWithEmailAndPassword(EmailString  ,PasswordString).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()){

                            DatabaseReference db = FirebaseDatabase.getInstance().getReference("Users").child(EmailString.replace("." ,"|"));
                            db.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                    String pic= snapshot.child("picName").getValue(String.class).toString();
                                    RemembrMeEditor = RememebrMe.edit();
                                    RemembrMeEditor.putString("Email" , EmailString);
                                    RemembrMeEditor.putString("Password" , PasswordString);
                                    RemembrMeEditor.putBoolean("isChecked" , flag.isChecked());
                                    RemembrMeEditor.putString("PicName" , pic);
                                    RemembrMeEditor.commit();
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {

                                }
                            });
                            ToMain.putExtra("CurrentUserEmail" , EmailString);
                            startActivity(ToMain);
                        }// successful
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(LoginScreen.this , "email or password are wrong" , Toast.LENGTH_LONG ).show();
                    }
                });
            }
        });



    }
}