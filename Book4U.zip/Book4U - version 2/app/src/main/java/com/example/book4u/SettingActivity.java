package com.example.book4u;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Arrays;

public class   SettingActivity extends AppCompatActivity {
    String[] buttons;
    ArrayAdapter <String> listAdapter;
    ListView listView;

    ImageButton BackToProfile;
    Intent back;
    Intent ToLogIn;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor Editor;
    Intent toProfileEdit ;
    Intent toCurrency;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        listView = findViewById(R.id.ListViewSettingsPage);
        BackToProfile = findViewById(R.id.BackToProfile);
        sharedPreferences = getSharedPreferences("UserLogedIn" , 0);
        ToLogIn = new Intent(this , LoginScreen.class);
        toProfileEdit = new Intent(this , ProfileEditPage.class);
        toCurrency = new Intent(this , currencyActivity.class);
        back = new Intent(this , ButtonNevigetionMainPage.class);
        buttons = new String[]{"Edit Profile","Shopping from", "Currency" , "Log Out"};
        ArrayList<String> input = new ArrayList<>();
        input.addAll(Arrays.asList(buttons));
        listAdapter = new ArrayAdapter<>(this, R.layout.list_view_profile_page, input);
        listView.setAdapter(listAdapter);

        BackToProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                back.putExtra("flag" , 1);
                startActivity(back);
            }
        });
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (buttons[position].equals("Log Out")){
                    Editor = sharedPreferences.edit();
                    Editor.putBoolean("isChecked" , false);
                    Editor.commit();
                    startActivity(ToLogIn);
                }
                else if (buttons[position].equals("Edit Profile")){
                    startActivity(toProfileEdit);
                } else if (buttons[position].equals("Currency")) {
                    startActivity(toCurrency);
                }
            }
        });
    }
}