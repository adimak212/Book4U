package com.example.book4u;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;

public class MainActivity extends AppCompatActivity {

    SharedPreferences RemembrMe ;
    SharedPreferences.Editor editor;
    boolean isChecked ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
        RemembrMe = getSharedPreferences("UserLogedIn", 0);
        isChecked = RemembrMe.getBoolean("isChecked", false);
        editor = RemembrMe.edit();
        Intent ToLogin = new Intent(this, LoginScreen.class);
        Intent ToMain = new Intent(this, ButtonNevigetionMainPage.class);

        Thread SplashTreadd = new Thread() {
            @Override
            public void run() {
                finish();
                if (isChecked) {
                    String rmString = RemembrMe.getString("Email", "");
                    ToMain.putExtra("SharedPEmail", rmString);
                    startActivity(ToMain);
                } else {
                    startActivity(ToLogin);
                }
            }
        };
        SplashTreadd.start();
    }
}