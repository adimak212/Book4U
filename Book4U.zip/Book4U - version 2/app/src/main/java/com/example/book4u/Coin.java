package com.example.book4u;

public class Coin {
    private String name;
    private String short_code;
    private String symbol;

    public Coin(String name, String short_code, String symbol) {
        this.name = name;
        this.short_code = short_code;
        this.symbol = symbol;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getShort_code() {
        return short_code;
    }

    public void setShort_code(String short_code) {
        this.short_code = short_code;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }
}
