package com.example.book4u;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.io.ByteArrayOutputStream;





public class ProfileEditPage extends AppCompatActivity {
    private static final int MY_CAMERA_REQUEST_CODE = 100;
    private static final int FROM_GALLERY = 1;
    private static final int FROM_CAMERA = 2;
    AlertDialog.Builder adb;
    AlertDialog ad;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference myref;
    SharedPreferences RememebrMe;
    SharedPreferences.Editor sharedPEditor;

    EditText name, phone, accountName;
    ImageView imageView;
    StorageReference storageReference;

    Button saveChanges , cancelChanges;
    Intent backToSettings;
    ActivityResultLauncher activityResultLauncher;
    Intent intent ;
    StorageReference mStorageRef;

    byte[] bytes;
    String picName="";

    boolean f=false;
    int flag;
    Uri uri;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_edit_page);
        name = findViewById(R.id.FullNameProfileEdit);
        accountName = findViewById(R.id.AccountNameProfilePage);
        phone = findViewById(R.id.PhoneProfileEditRegister);
        imageView = findViewById(R.id.ProfileImageProfilePageEdit);
        saveChanges = findViewById(R.id.saveChangesButton);
        cancelChanges = findViewById(R.id.cancelChangesButton);
        adb = new AlertDialog.Builder(this);
        intent = new Intent();
        firebaseDatabase = firebaseDatabase.getInstance();
        RememebrMe = this.getSharedPreferences("UserLogedIn", 0);
        storageReference = FirebaseStorage.getInstance().getReference("Images/users/" + RememebrMe.getString("Email", "").replace(".", "|")).child(RememebrMe.getString("PicName" , ""));
        backToSettings = new Intent(this , SettingActivity.class);
        myref = firebaseDatabase.getReference("Users").child(RememebrMe.getString("Email", "").replace(".", "|"));
        myref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                accountName.setText(snapshot.child("accountName").getValue().toString());
                name.setText(snapshot.child("fullName").getValue().toString());
                phone.setText(snapshot.child("phoneNumber").getValue().toString());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        getCurrentUserPhoto(storageReference);
        saveChanges.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myref.child("accountName").setValue(accountName.getText().toString());
                myref.child("fullName").setValue(name.getText().toString());
                myref.child("phoneNumber").setValue(phone.getText().toString());
                myref.child("picName").setValue(picName);
                if (!picName.equals("")){
                    sharedPEditor = RememebrMe.edit();
                    sharedPEditor.putString("PicName" , picName);
                    sharedPEditor.commit();
                }

                startActivity(backToSettings);
            }
        });
        cancelChanges.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(backToSettings);
            }
        });

        activityResultLauncher= registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {


                        if (result.getData()!=null && result.getData().getAction()==null &&result.getResultCode() == Activity.RESULT_OK) {
                            Intent data = result.getData();
                            uri = data.getData();
                            picName=System.currentTimeMillis() + "."+ getFileExtension(uri);
                            imageView.setImageURI(uri);
                            Toast.makeText(ProfileEditPage.this, picName, Toast.LENGTH_LONG).show();
                            flag=FROM_GALLERY;
                            f= true;//boolean if must enter picture


                        }


                        else if (result.getData()!=null   && result.getResultCode() == Activity.RESULT_OK) {
                            Bitmap bitmap = (Bitmap) result.getData().getExtras().get("data");
                            picName=System.currentTimeMillis() + "."+ "jpg";
                            //imageView.setImageURI(uri);
                            Toast.makeText(ProfileEditPage.this, picName, Toast.LENGTH_LONG).show();
                            ByteArrayOutputStream baos = new ByteArrayOutputStream();
                            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                            bytes = baos.toByteArray();
                            flag=FROM_CAMERA;
                            f= true;
                            if (flag == FROM_GALLERY) {
                                mStorageRef = FirebaseStorage.getInstance().getReference("Images/users/" + RememebrMe.getString("Email", "").replace(".", "|"));
                                mStorageRef = mStorageRef.child(picName);

                                mStorageRef.putFile(uri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {

                                    @Override
                                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                        Toast.makeText(ProfileEditPage.this, "תמונה הועלתה", Toast.LENGTH_LONG).show();


                                    }
                                }).addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {

                                        Toast.makeText(ProfileEditPage.this, "" + e.getMessage(), Toast.LENGTH_LONG).show();
                                    }
                                });
                            }
                            else {

                                mStorageRef = FirebaseStorage.getInstance().getReference("Images/users/" + RememebrMe.getString("Email", "").replace(".", "|"));
                                mStorageRef = mStorageRef.child(picName);
                                imageView.setImageBitmap(bitmap);
                                UploadTask uploadTask = mStorageRef.putBytes(bytes);
                            }
                        }
                    }
                });
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                adb.setTitle("pick picture");
                adb.setMessage("choose picture from gallery/camera");
                adb.setCancelable(true);
                adb.setPositiveButton("גלריה", new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface d, int i) {

                        intent.setType("image/*");
                        intent.setAction(Intent.ACTION_OPEN_DOCUMENT);
                        activityResultLauncher.launch(intent);
                    }
                });
                adb.setNeutralButton("מצלמה", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int i) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(android.Manifest.permission.CAMERA) == PackageManager.PERMISSION_DENIED) {
                            if (ActivityCompat.checkSelfPermission(ProfileEditPage.this, android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                                requestPermissions(new String[]{android.Manifest.permission.CAMERA}, MY_CAMERA_REQUEST_CODE);
                            }
                        }
                        else {
                            Intent intent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                            activityResultLauncher.launch(intent);
                        }
                    }
                });
                ad = adb.create();
                ad.show();
            }
            });
    }
    private String getFileExtension(Uri uri) {
        ContentResolver cR = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cR.getType(uri));
    }

    private void getCurrentUserPhoto(StorageReference storageReference) {
        storageReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                Picasso.get().load(uri).into(imageView);
            }
        });
    }
}