package com.example.book4u;

import android.media.Image;

public class Book {


    private String book_authors ;
    private String book_desc;
    private String book_isbn;
    private String book_pages;
    private String book_rating;
    private String book_title;
    private String genres;
    private String image_url;



    public Book(String book_authors, String book_desc, String book_isbn, String book_pages, String book_rating, String book_title, String genres,  String image_url) {
        this.book_authors = book_authors;
        this.book_desc = book_desc;
        this.book_isbn = book_isbn;
        this.book_pages = book_pages;
        this.book_rating = book_rating;
        this.book_title = book_title;
        this.genres = genres;
        this.image_url = image_url;
    }

    public Book() {
        this.book_authors = "";
        this.book_desc = "";
        this.book_isbn = "";
        this.book_pages = "";
        this.book_rating = "";
        this.book_title = "";
        this.image_url = "";
    }

    public String getBook_authors() {
        return book_authors;
    }

    public void setBook_authors(String book_authors) {
        this.book_authors = book_authors;
    }

    public String getBook_desc() {
        return book_desc;
    }

    public void setBook_desc(String book_desc) {
        this.book_desc = book_desc;
    }

    public String getBook_isbn() {
        return book_isbn;
    }

    public void setBook_isbn(String book_isbn) {
        this.book_isbn = book_isbn;
    }

    public String getBook_pages() {
        return book_pages;
    }

    public void setBook_pages(String book_pages) {
        this.book_pages = book_pages;
    }

    public String getBook_rating() {
        return book_rating;
    }

    public void setBook_rating(String book_rating) {
        this.book_rating = book_rating;
    }

    public String getBook_title() {
        return book_title;
    }

    public void setBook_title(String book_title) {
        this.book_title = book_title;
    }

    public String getImage_url() {
        return image_url;
    }

    public void setImage_url(String image_url) {
        this.image_url = image_url;
    }

    public String getGenres() {
        return genres;
    }

    public void setGenres(String genres) {
        this.genres = genres;
    }

    @Override
    public String toString() {
        return "Book{" +
                "book_authors='" + book_authors + '\'' +
                ", book_desc='" + book_desc + '\'' +
                ", book_isbn='" + book_isbn + '\'' +
                ", book_pages='" + book_pages + '\'' +
                ", book_rating='" + book_rating + '\'' +
                ", book_title='" + book_title + '\'' +
                ", genres='" + genres + '\'' +
                ", image_url='" + image_url + '\'' +
                '}';
    }
}
