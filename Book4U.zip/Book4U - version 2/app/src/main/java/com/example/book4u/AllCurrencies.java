package com.example.book4u;

import java.util.List;

public class AllCurrencies {
    private List<Coin> response;

    public List<Coin> getResponse() {
        return response;
    }

    public void setResponse(List<Coin> response) {
        this.response = response;
    }

    public AllCurrencies(List<Coin> response) {
        this.response = response;
    }
}
